// idnode.js
const NODE_IDS = [
    "12D3KooWGjfoTJBfGbAJP5yWVmnYTAZ8xtCEwBGDKMvQYMjyQeED",
    "12D3KooWQdSHEhnSRsdwMRJ4hf9Yw6bWbDTwbJmsfZ6RPRJn3tJD",
    "12D3KooWEqBuSgr4HUbQEmiWwroMor6LRj37GfUdixcMSaPX7FSP",
    "12D3KooWL1wYezLJ9m8ErAQb9nLfSVnMJX6dmLE5hSFC1hC14hYS",
    "12D3KooWEcDjEpUfBZtpRx4s2GDevYLrizgnssA2DESN568zZnk4"
    
    // Add more node IDs as needed
];

module.exports = {
    NODE_IDS
};

